# AGENTS.md - Japanese Learning Hub

## 專案規範與架構
本專案為 JLPT N3/N2 日文學習知識庫，採用純前端 HTML/CSS/JavaScript 架構，並透過 JSON 檔案進行資料驅動。

### 目錄結構
- `index.html`: 首頁導覽
- `pages/`: 各學習專區頁面 (單字、文法、慣用句、練習題、閱讀、聽力)
- `css/`: 樣式表
- `js/`: 互動邏輯與搜尋引擎
- `data/`: 結構化 JSON 學習資料
- `assets/`: 媒體資源 (圖片與音檔)
